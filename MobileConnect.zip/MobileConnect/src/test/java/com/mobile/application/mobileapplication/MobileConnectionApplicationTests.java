package com.mobile.application.mobileapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileConnectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
