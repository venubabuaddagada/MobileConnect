package com.mobile.application.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobile.application.dto.UserResponse;
import com.mobile.application.entity.Request;
import com.mobile.application.entity.User;
import com.mobile.application.repository.RequestRepository;
import com.mobile.application.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	RequestRepository requestRepo;
	
	@Autowired
	UserRepository userRepo;
	
	public Request getRequestDetails(int requestId) {
		return requestRepo.getAllByRequestId(requestId);
	}
	
	@Override
	public UserResponse userRegistration(User user) {
		userRepo.save(user);
		UserResponse userReponse = userResponse();
		Optional<UserResponse> response = Optional.of(userReponse);
		if(response.isPresent()) {
			Request request = new Request(userReponse.getRequestId(), user.getUserId(), 111, userReponse.getStatus(), false);
			saveRequest(request);
		}		
		return userReponse;
	}
	
	private int requestIdGen() {
        return ++nextRequestNumber;
    }
	
	private void saveRequest(Request request) {
		requestRepo.save(request);
	}
	
	private UserResponse userResponse() {
		UserResponse userReponse = new UserResponse();
		userReponse.setRequestId(requestIdGen());
		userReponse.setStatus("inProgress");
		return userReponse;
	}
}
