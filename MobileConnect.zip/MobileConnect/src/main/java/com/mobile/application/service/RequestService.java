package com.mobile.application.service;

import com.mobile.application.entity.Request;

public interface RequestService {
	
	public void saveRequest(Request request);

}